#pragma once
#include "GameElement.h"
class ElementMove :public GameElement
{
	int vitess;

public:
	ElementMove(int a = 0, int b = 0, int v = 1) :GameElement(a, b), vitess(v) {}

	int getV()const { return vitess; }

	void setV(int a) {
		if (a < 0) throw Erreur("La position est negatif");
		vitess = a;
	}
	void moveUp() {
		setY(getY() - vitess);
	}
	void moveDown() {
		setY(getY() + vitess);
	}
	void moveLeft() {
		setX(getX() - vitess);
	}
	void moveRight() {
		setX(getX() + vitess);
	}
	void moveUpLeft() {
		moveUp();
		moveLeft();
	}
	void moveUpRight() {
		moveRight();
		moveUp();
	}
	void moveDownLeft() {
		moveLeft();
		moveDown();
	}
	void moveDownRight() {
		moveDown();
		moveRight();
	}
};

