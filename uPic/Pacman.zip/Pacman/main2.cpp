#pragma once
#include <iostream>
#include <sstream>
#include <string>

#include <SFML\Graphics\Color.hpp>
#include <SFML/Graphics/RenderWindow.hpp>
#include <SFML/Graphics/VertexArray.hpp>
#include <SFML/Window/Event.hpp>
#include <SFML/Window/Mouse.hpp>
#include <SFML/Graphics/Font.hpp>

#include <Graphe.h>
#include <FenetreGrapheSFML.h>
#include <InfosGrapheDessin.h>
#include <SFML/Graphics.hpp>

#include "labyrintheM.h"
#include "Pacman.h"
#include "Gomme.h"

using namespace std;
using namespace sf;


int main() {
	labyrintheM* lab=new labyrintheM();
	
	Pacman* pacman = new Pacman(78, 168, 90.f);
	//Gomme gomme(78, 168);
	/*
	Texture pacmanT;
	pacmanT.loadFromFile("Imagess/Pacman.png");
	
	RectangleShape player(Vector2f(30.0f, 30.0f));
	player.setTexture(&pacmanT);
	player.setPosition(Vector2f(10.f,10.f));
	*/
	RectangleShape player = pacman->getPacman();
	//RectangleShape gomme = g.getGomme();
	//RectangleShape gomme2 = g.getGomme2();
	Vecteur2D  coinBG(-1, -1), coinHD(8, 8);
	string titre("Pacman Game");
	//unsigned int magenta = Color::Magenta.toInteger();
	Font font1, font2;
	string nomFichierFonte1 = "mespolices\\abaddon.ttf";
	string nomFichierFonte2 = "mespolices\\ActionManBoldItalic.ttf";
	bool ok = font1.loadFromFile(nomFichierFonte1);
	ok = font2.loadFromFile(nomFichierFonte2);
	FenetreGrapheSFMLAvecAxesRepereMonde fenetreGraphe(titre, Constantes::fondCarte, coinBG, coinHD, Constantes::largeur, Constantes::hauteur, font1, font2);
	

	RectangleShape tab_Gomme[49];
	Gomme* tabGomme[49];

	
	/*
	for (int i=0;i<49;i++)
	{
		tab_Gomme[i] = g.getGomme();
	}
	*/
	/*
	int i = 0;
	for (int j=78;j<=78+90*6;j+90)
	{
		for (int k=168;k<=168+90*6;j+90)
		{
			tab_Gomme[i].setPosition(Vector2f(j, k));
			fenetreGraphe.fenetre.draw(tab_Gomme[i]);
			i++;
		}
		
	}
	*/
	//Gomme
	int k = 0;
	for (int i = 78; i <= 78 + 90 * 6; i += 90)
	{
		for (int j = 168; j <= 168 + 90 * 6; j += 90)
		{
			tabGomme[k] =new Gomme(i, j);
			tab_Gomme[k] = tabGomme[k]->getGomme();

			k++;
		}
	}
	


	while (fenetreGraphe.fenetre.isOpen())
	{
		Event event;
		while (fenetreGraphe.fenetre.pollEvent(event))
		{

			if (event.type == Event::Closed) /*(event.type == Event::EventType::Closed)*/
				fenetreGraphe.fenetre.close();
		}
		//Mouse control
		if (Mouse::isButtonPressed(Mouse::Left))
		{
			Vector2i mousePos = Mouse::getPosition(fenetreGraphe.fenetre);
			player.setPosition((float)mousePos.x, (float)mousePos.y);
		}

		//Keyboard control
		if (Keyboard::isKeyPressed(Keyboard::Key::Q)) 
			pacman->moveLeft();
		if (Keyboard::isKeyPressed(Keyboard::Key::D))
			pacman->moveRight();
		if (Keyboard::isKeyPressed(Keyboard::Key::S))
			pacman->moveDown();
		if (Keyboard::isKeyPressed(Keyboard::Key::Z))
			pacman->moveUp();
		if (Keyboard::isKeyPressed(Keyboard::Key::Numpad7))
			pacman->moveUpLeft();
		if (Keyboard::isKeyPressed(Keyboard::Key::Numpad9))
			pacman->moveUpRight();
		if (Keyboard::isKeyPressed(Keyboard::Key::Numpad1))
			pacman->moveDownLeft();
		if (Keyboard::isKeyPressed(Keyboard::Key::Numpad3))
			pacman->moveDownRight();
		/**********/
		
		//fenetreGraphe.fenetre.display();
		fenetreGraphe.fenetre.clear(Color(155, 155, 155));
		ok = lab->getMap()->dessine(fenetreGraphe);
		
		

		//Gomme
		for (int k=0;k<49;k++)
		{
			fenetreGraphe.fenetre.draw(tab_Gomme[k]);
			tabGomme[k]->render(&tab_Gomme[k]);
		}

	
		
		
		fenetreGraphe.fenetre.draw(player);
		pacman->render(&player);
		fenetreGraphe.fenetre.display();	//ordonn��e
		

	}



	delete pacman;
	for (int i=0;i<49;i++)
	{
		delete(tabGomme[i]);
	}
	return 0;
}