#pragma once

class Constantes {
public:
	/**************** Couleur ***************/
	static const unsigned int jaune0 = 0xDFFF00FF;   // jaune opaque
	static const unsigned int jaune1 = 0xDFFF00C0;   // jaune presque opaque
	static const unsigned int jaune2 = 0xDFFF0064;   // jaune un peu transparent
	static const unsigned int jaune3 = 0xDFFF0020;	// jaune presque transparent

	static const unsigned int tangerine0 = 0xFF7F00FF; // tangerine opaque
	static const unsigned int tangerine1 = 0xFF7F00DF; // tangerine presque opaque
	static const unsigned int tangerine2 = 0xFF7F00BF; // tangerine un peu transparent
	static const unsigned int tangerine3 = 0xFF7F0060; // tangerine presque transparent
	static const unsigned int tangerine4 = 0xFF7F0000; // tangerine  transparent


  //unsigned int jauneOpaque
	static const unsigned int turquoise = 0x00CED1FF;	// couleur turquoise opaque. pr��fixe 0x pour h��xad��cimal. format RGBA
	static const unsigned int vertCitron = 0x00FF00FF;







	/**************Param��tre**************/
	//Couleur du fond
	static const unsigned int fondCarte = 0xEFEFEFFF;	// sorte de gris clair ~= ��tain pur

	static const int largeur = 800, hauteur = 800; //Taille de la fen��tre

};
