
#pragma once
#include<Erreur.h>

class GameElement
{
	float x, y;
public:
	GameElement(float a = 0, float b = 0) :x(a), y(b) {}
	float getX()const { return x; }
	float getY()const { return y; }
	void setX(float a) {
		//if (a < 0) throw Erreur("La position est negatif");
		x = a;
	}
	void setY(float a) {
		//if (a < 0) throw Erreur("La position est negatif");
		y = a;
	}
};

