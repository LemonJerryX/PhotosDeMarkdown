#pragma once
#include <Graphe.h>
#include <FenetreGrapheSFML.h>
#include <InfosGrapheDessin.h>
#include "Constantes.h"
#include "Pacman.h"


class labyrintheM
{
	Graphe<Peinture, VSommet>* map; //Graphe<int,int>* map;
	Sommet<VSommet>* s[7][7];//Sommet<int>* s[7][7];
	Arete<Peinture, VSommet>* enX[42];
	Arete<Peinture, VSommet>* enY[42];
	Arete<Peinture, VSommet>* enSlash[28];
	unsigned int magenta;

	Pacman* pacman;


public:
	 
	labyrintheM() {
		//pacman = new Pacman();
		//map->creeSommet(VSommet("Pacman", Vecteur2D(0, 1), Constantes::jaune3));


		//Initialiser
		map = new Graphe<Peinture, VSommet>();
		magenta = Color::Magenta.toInteger();

		//Creer les sommet dans graphe
		int i = -1;
		for (int y = 0; y < 7; y++) {
			for (int x = 0; x < 7; x++) {
				s[y][x] = map->creeSommet(VSommet(""+x, Vecteur2D(x, y), magenta));
			}
		}


		i = 0;
		while (i < 42)
		{
			for (int y = 0; y < 7; y++) {
				for (int x = 0; x < 7; x++) {
					if (x < 6)	//le dernier point li��e le suivant (nullptr)
					{
						enX[i] = map->creeArete(Peinture(Constantes::vertCitron, Constantes::tangerine0), s[y][x], s[y][x + 1]);
						i++;
					}
				}
			}
		}

		//creer les sommets en y(clonne)
		i = 0;
		while (i < 42)
		{
			for (int x = 0; x < 7; x++) {
				for (int y = 0; y < 7; y++) {
					if (y < 6)
					{
						enY[i] = map->creeArete(Peinture(Constantes::vertCitron, Constantes::tangerine1), s[y][x], s[y + 1][x]);
						i++;
					}
				}
			}
		}

		//creer les arete en slash
		i = 0;
		while (i < 28)
		{
			//premier ligne slash
			for (int x = 0; x < 5; x++) {
				if (x != 2) {
					//enSlash[i] = map->creeArete(tabInt[i], s[x + 1][x], s[x + 2][x + 1]);
					enSlash[i] = map->creeArete(Peinture(Constantes::vertCitron, Constantes::tangerine2), s[x + 1][x], s[x + 2][x + 1]);
					i++;
				}

			}

			//deuxieme ligne slash 
			for (int x = 0; x < 6; x++) {
				enSlash[i] = map->creeArete(Peinture(Constantes::vertCitron, Constantes::tangerine2), s[x][x], s[x + 1][x + 1]);
				i++;
			}


			//troixieme ligne slash 
			for (int x = 1; x < 6; x++) {
				if (x != 3) {
					enSlash[i] = map->creeArete(Peinture(Constantes::vertCitron, Constantes::tangerine2), s[x - 1][x], s[x][x + 1]);
					i++;
				}
			}

			//4ieme ligne slash
			for (int x = 0; x < 5; x++) {
				if (x != 2) {
					enSlash[i] = map->creeArete(Peinture(Constantes::vertCitron, Constantes::tangerine2), s[5 - x][x], s[5 - x - 1][x + 1]);
					i++;
				}
			}

			//5ieme ligne slash
			for (int x = 0; x < 6; x++) {
				enSlash[i] = map->creeArete(Peinture(Constantes::vertCitron, Constantes::tangerine2), s[6 - x][x], s[6 - x - 1][x + 1]);
				i++;
			}

			//6ieme ligne slash
			for (int x = 1; x < 6; x++) {
				if (x != 3) {
					enSlash[i] = map->creeArete(Peinture(Constantes::vertCitron, Constantes::tangerine2), s[7 - x][x], s[7 - x - 1][x + 1]);
					i++;
				}
			}
		}
	}

	~labyrintheM() {

		for (int y = 0; y < 7; y++) {
			for (int x = 0; x < 7; x++) {
				delete(s[y][x]);
			}
		}

		for (int i = 0; i < 42; i++) {
			delete(enX[i]);
			delete(enY[i]);
			if (i < 28)
				delete(enSlash[i]);
		}

	}
	
	Graphe<Peinture, VSommet>* getMap() const {
		return map;
	}
	
};
