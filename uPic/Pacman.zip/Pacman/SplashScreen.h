#pragma once
class SplashScreen
{
public:
	void Show(sf::RenderWindow& window);
};

