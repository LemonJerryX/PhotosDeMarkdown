#pragma once
#include "ElementMove.h"
#include<stdbool.h>
#include <SFML/Graphics/Texture.hpp>
#include <windows.h>


using namespace sf;

class Pacman :public ElementMove
{
	Texture pacmanT;
	RectangleShape player;
	bool up, down, left, right;

public:
	Pacman(int x = 0, int y = 0, int v = 1) :ElementMove(x, y, v), up(false), down(false), left(false), right(false) {
		pacmanT.loadFromFile("Imagess/Pacman.png");
		player=RectangleShape(Vector2f(30.0f, 30.0f));
		player.setTexture(&pacmanT);

	}

	void render(RectangleShape *s) {
		s->setPosition(getX(), getY());
		cout << "position (" << getX() << " , " << getY() << endl;
		Sleep(50);
	}


	Texture getPacmanT() {
		return pacmanT;
	}

	RectangleShape getPacman() {
		return player;
	}
};









/**************************
#pragma once
#include "ElementMove.h"
#include<stdbool.h>
#include<SFML/GRAPHICS/Sprite.hpp>
#include<iostream>
#include <windows.h>

using namespace sf;
using namespace std;
class Pacman :public ElementMove
{

public:
	Pacman(float x = 0, float y = 0, float v = 1) :ElementMove(x, y, v) {}

	void render(Sprite *s) {
		s->setPosition(getX(), getY());
		cout << "position (" << getX() << " , " << getY() << endl;
		Sleep(150);
	}


};

*/
