#pragma once
#include "ElementMove.h"
#include<SFML/GRAPHICS/Sprite.hpp>
#include<stdlib.h>
class Phandome :public ElementMove
{
	int dir;
public:
	Phandome(int x = 0, int y = 0, int v = 1) :ElementMove(x, y, v), dir(-1) {}
	void nextStep() {
		dir = rand() % 4;
	}
	void render(sf::Sprite* s) {
		move();
		s->setPosition(getX(), getY());
	}
	void move() {
		nextStep();
		if (dir == 0)  moveUp();
		else if (dir == 1) moveDown();
		else if (dir == 2) moveLeft();
		else if (dir == 3) moveRight();
		else {}
	}
};

