#pragma once
#include "GameElement.h"
#include <SFML/Graphics/Texture.hpp>
#include <SFML/Graphics/RectangleShape.hpp>
#include <windows.h>

using namespace sf;
class Gomme:public GameElement
{
private:
	Texture gommeT;
	RectangleShape gomme;
	RectangleShape gomme2;
public:
	//Constructeur par d��faut
	Gomme(float x=0, float y=0):GameElement(x,y){
		gommeT.loadFromFile("Imagess\\Gomme.png");
		gomme = RectangleShape(Vector2f(30.0f, 30.0f));
		gomme.setTexture(&gommeT);
		/*
		gomme2 =RectangleShape(Vector2f(30.0f, 30.0f));
		gomme2.setTexture(&gommeT);
		*/

	}

	RectangleShape getGomme() const {
		return gomme;
	}

	RectangleShape getGomme2() const {
		return gomme2;
	}

	void render(RectangleShape *s) {
		//for (int i = 78; i <= (78 + 90 * 6);i+90)
		//{
			//for (int j = 168; j<=(168+90*6);j+90)
			//{
				//s->setPosition(Vector2f((float)78, (float)j));
			//}
		//}
		
		//float i = 78;
		//while (i<=78+90*6) {
			//RectangleShape* s = new RectangleShape();
			//s->setTexture(&gommeT);
			//s->setPosition(Vector2f(i, 168));
			//i + 90;
		//}

		s->setPosition(Vector2f(getX(), getY()));
		
	}


	



};

