#pragma once
#include <map>
#include <SFML/GRAPHICS/Texture.hpp>
#include<SFML/GRAPHICS/Image.hpp>
#include<SFML/GRAPHICS/Sprite.hpp>
#include <iostream>
using namespace std;
using namespace sf;
class SpriteFactory
{
	static SpriteFactory* INSTANCE;
	map<string, Sprite> tab_Sprite;
	Texture t_pacman, t_gomme;
	Sprite s_pacman, s_gomme;

public:
	
	 SpriteFactory* getInstance() {
		 if (!t_pacman.loadFromFile("imagess\\Pacman.png") ||
			 !t_gomme.loadFromFile("imagess/Gomme.png")
			 )
			 cout << "Erreur" << endl;

		 s_pacman.setTexture(t_pacman);
		 s_gomme.setTexture(t_gomme);
	}
	Sprite getSprite(string nom);
	void setTaille(int largeur, int hauteur);
};

