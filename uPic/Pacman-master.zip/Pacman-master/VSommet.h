#pragma once
#include <iostream>
#include <sstream>
#include <vector>
#include "Vecteur2D.h"
using namespace std;
class VSommet
{
public:
	constexpr static  int rayonDisquePixels = 40;
	Vecteur2D p;		  // position
	unsigned int couleur; // couleur par d�faut au format rgba
	

	VSommet(const Vecteur2D & p, const unsigned int couleur = 0x0000FFAA) : p(p), couleur(couleur) {}


	virtual operator string () const { ostringstream o; o << "( " << p << ", " << couleur << ")"; return o.str(); }

	friend ostream & operator << (ostream & o, const VSommet & vSommet) { return o << (string)vSommet; }
};
