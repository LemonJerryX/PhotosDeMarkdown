#pragma once
#include <iostream>
#include <sstream>
#include <string>

#include <SFML\Graphics\Color.hpp>
#include <SFML/Graphics/RenderWindow.hpp>
#include <SFML/Graphics/VertexArray.hpp>
#include <SFML/Window/Event.hpp>
#include <SFML/Window/Mouse.hpp>
#include <SFML/Graphics/Font.hpp>

#include "Graphe.h"
#include "FenetreGrapheSFML.h"
#include "InfoSommet.h"
#include "InfoArete.h"
#include <fstream>

using namespace std;
using namespace sf;

class Maze {
public:
	//Des constantes
	const static int MAZE_LARGEUR = 5;
	const static int MAZE_HAUTEUR = 5;
	const static int DH = 1;
	const static int D = 2;
	const static int DB = 3;
	const static int B = 4;
	const static int GB = 5;
	const static int G = 6;
	const static int GH = 7;
	const static int H = 8;
	const unsigned int turquoise = 0x00CED1FF;	// couleur turquoise opaque. pr�fixe 0x pour h�xad�cimal. format RGBA
	const unsigned int rouge = 0xFF000000;

	Graphe<InfoArete, InfoSommet> graphe;
	vector<Sommet<InfoSommet> *> sommets;
	//vector<Arete<InfoArete, InfoSommet> *> aretes;

	void refroidirAretes() {
		for (PElement<Arete<InfoArete, InfoSommet>> * aux = graphe.lAretes; aux != NULL; aux = aux->s)
			aux->v->v.diminuerPoids(0x00000008);
	}

	static int calculeDecalageClef(int direction) {
		switch (direction) {
		case DH:
			return -1 * MAZE_LARGEUR + 1;
		case D:
			return 1;
		case DB:
			return MAZE_LARGEUR + 1;
		case B:
			return MAZE_LARGEUR;
		case GB:
			return MAZE_LARGEUR - 1;
		case G:
			return -1;
		case GH:
			return -1 * MAZE_LARGEUR - 1;
		case H:
			return -1 * MAZE_LARGEUR;
		default:
			return 0;
		}
	}
	
	Maze() {
		
		//Cr�ation des sommets
		for (int i = 0; i < MAZE_HAUTEUR*MAZE_LARGEUR; i++)
			sommets.push_back(graphe.creeSommet(InfoSommet(VSommet(Vecteur2D(i % MAZE_LARGEUR, MAZE_HAUTEUR - i / MAZE_LARGEUR)),InfoAStar::InfoAStar())));
		

	ifstream fichier("graphe.txt");
	if (fichier) {
		string line;
		string info;
		int numeroSommet = 0;
		int numeroSommetRelie;
		double cout = 0;
		while (getline(fichier, line)) {
			//Split
			
			do
			{
				info = line.substr(0, line.find(","));
				numeroSommetRelie = numeroSommet + calculeDecalageClef(stoi(info));
				stoi(info) % 2 == 0 ? cout = 1 : cout = 1.4;
				graphe.creeArete(InfoArete(cout,turquoise, rouge), sommets[numeroSommet], sommets[numeroSommetRelie]);

			} while ((line = line.substr(line.find(',') + 1)) != "");

			numeroSommet++;
		}
		fichier.close();
	}
	else
		cerr << "Impossible d'ouvrir le fichier !" << endl;
	}
	
};