#pragma once
#include "SpriteFactory.h"
#include <SFML/Graphics.hpp>

template <class InfoSommet>
class Sommet;
class InfoSommet;
class GameElement {
private :
    RectangleShape body;
	Sommet<InfoSommet>* position;
	Sommet<InfoSommet>* init_position;
	//Pour le moment Etat ne sert � rien, je le garde quand m�me au cas o� on en aura besoin pour superMode
	int etat;
public:

	static const int NORMAL = 0; //etat


	//Un gameElement est cr�er avec le sommet auquel il sera reli�
	GameElement(Sommet<InfoSommet> *position, int etat);
	virtual ~GameElement ();

	//m�thode virtuelle � compl�ter par les classe pr�cise, �a r�tourne le Sprite des �lements
	virtual Sprite getSprite() const = 0;


	inline void setEtat(int etat);
    inline int getEtat() const;

	
	Sommet<InfoSommet>* getInitPosition() const;

	Sommet<InfoSommet>* getPosition () const;
	
	/*
	*chaque fois quand on modifie la Position, il faut d'abord effacer les infos sur l'ancien sommet
	* car on dit qu'un gameElement ne peut �tre que sur un seul sommet � la fois
	* apr�s avoir efface, on lui affecte la nouvelle position(de type Sommet)
	* D�tails dans le fichier .cpp
	*/
    virtual void setPosition (Sommet<InfoSommet> *position);
};

inline void GameElement::setEtat(int etat){GameElement::etat = etat;}

inline int GameElement::getEtat () const{return etat;}
