#include "SpriteFactory.h"
#include "Erreur.h"
using namespace sf;
SpriteFactory* SpriteFactory::INSTANCE = NULL;
SpriteFactory::SpriteFactory() {
	if (!txtPacman.loadFromFile("images\\Pacman.png") ||
		!txtFantRouge.loadFromFile("images\\FantRouge.png") ||
		!txtFantRose.loadFromFile("images\\FantRose.png") ||
		!txtFantBleu.loadFromFile("images\\FantBleu.png") ||
		!txtStartMenu.loadFromFile("images\\StartMenu.png") ||
		!txtGameOver.loadFromFile("images\\GameOver.png") ||
		!txtGameWin.loadFromFile("images\\GameWin.png") ||
		!txtGomme.loadFromFile("images\\Gomme.png")) throw Erreur("�chec chargement des images");

	sptPacman.setTexture(txtPacman);
	sptFantRouge.setTexture(txtFantRouge);
	sptFantRose.setTexture(txtFantRose);
	sptFantBleu.setTexture(txtFantBleu);
	sptGomme.setTexture(txtGomme);
	sptStartMenu.setTexture(txtStartMenu);
	//sptStartMenu.setScale(Vector2f(5, 5));
	sptGameOver.setTexture(txtGameOver);
	//sptGameOver.setScale(Vector2f(5, 5));
	sptGameWin.setTexture(txtGameWin);
	//sptGameWin.setScale(Vector2f(5, 5));
	

	tab_Sprite["Pacman"] = sptPacman;
	tab_Sprite["FantRouge"] = sptFantRouge;
	tab_Sprite["FantRose"] = sptFantRose;
	tab_Sprite["FantBleu"] = sptFantBleu;
	tab_Sprite["Gomme"] = sptGomme;
	tab_Sprite["StartMenu"] = sptStartMenu;
	tab_Sprite["GameOver"] = sptGameOver;
	tab_Sprite["GameWin"] = sptGameWin;
	//la taille par d�faut est 60px
	setTaille(75, 75);
}

SpriteFactory::~SpriteFactory() {}

SpriteFactory* SpriteFactory::getInstance() {
	if (INSTANCE == NULL)
		INSTANCE = new SpriteFactory();
	return INSTANCE;
}

Sprite SpriteFactory::getSprite(string nom) {
	return tab_Sprite[nom];
}

void SpriteFactory::setTaille(int largeur, int hauteur) {
	for (map<string, Sprite> ::iterator it = tab_Sprite.begin(); it != tab_Sprite.end(); it++)
	{
		Sprite sp = it->second;
		Vector2u taille_originale = sp.getTexture()->getSize();
		it->second.setScale(float(largeur)/taille_originale.x, float(hauteur)/taille_originale.y);
	}
}
