#pragma once
#include <SFML\Graphics\Color.hpp>
#include <iostream>
#include <sstream>
#include <string>
#include "Vecteur2D.h"

class InfoArete
{
public:
	unsigned int fond;		// couleur du fond (ou sous-couche de peinture)
	unsigned int devant;	// couleur masquant  la couleur du fond. ou derni�re couche de peinture.
							// Elle masque pas du tout, partiellement ou enti�rement la couleur du fond
	double cout1;
	unsigned int poids;		//le poids d'une arete, ici �a represente l'opacit� de la couleur devant 
	InfoArete(const double & cout1, const unsigned int couleurFond = 0x00CED1FF, const unsigned int couleurDevant = 0xFF000000, const unsigned int poids = 0x00000000) :cout1(cout1), fond(couleurFond), devant(couleurDevant), poids(poids){}

	void diminuerPoids(unsigned int nbPoidADiminuer) {
		poids > nbPoidADiminuer? poids -= nbPoidADiminuer : poids = 0x00000000;
	}

	unsigned int getDevant() const{
		return devant + poids;
	}
	virtual operator string () const { ostringstream o; o << "( " << fond << ", " << devant << ")"; return o.str(); }

	friend ostream & operator << (ostream & o, const InfoArete & peinture) { return o << (string)peinture; }
};
