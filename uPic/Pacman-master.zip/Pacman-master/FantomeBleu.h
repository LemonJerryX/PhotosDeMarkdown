#pragma once
#include "GameElement.h"

class FantomeBleu : public GameElement {
public:
	FantomeBleu(Sommet<InfoSommet> *position, int etat = GameElement::NORMAL) :GameElement(position, etat) {}
	virtual ~FantomeBleu() {}
	Sprite getSprite() const {
		return SpriteFactory::getInstance()->getSprite("FantBleu");
	}

};
