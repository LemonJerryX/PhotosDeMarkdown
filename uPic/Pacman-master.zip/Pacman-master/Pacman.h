#pragma once
#include "GameElement.h"

class Pacman : public GameElement{
    public:
		Pacman(Sommet<InfoSommet> *position, int etat = GameElement::NORMAL) :GameElement(position, etat) {}
		virtual ~Pacman(){}
		Sprite getSprite() const {
			return SpriteFactory::getInstance()->getSprite("Pacman");
		}
};
