#include "GameElement.h"
#include "Sommet.h"
#include "InfoSommet.h"

GameElement::GameElement(Sommet<InfoSommet> *position, int etat = GameElement::NORMAL){
	init_position = position;
	setPosition(position);
	setEtat(etat);
}

GameElement::~GameElement(){};

Sommet<InfoSommet>* GameElement::getInitPosition() const {
	return init_position;
}
Sommet<InfoSommet>* GameElement::getPosition () const{
    return position;
}

void GameElement::setPosition (Sommet<InfoSommet> *position){
	//Si c'est NULL, rien � effacer 
	if(this->position != NULL)
		this->position->v.deleteElement(this);
    this->position = position;
	this->position->v.addElement(this);

}

