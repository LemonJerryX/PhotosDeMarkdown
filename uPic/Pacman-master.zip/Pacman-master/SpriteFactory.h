#pragma once
#include <SFML/GRAPHICS/Texture.hpp>
#include<SFML/GRAPHICS/Image.hpp>
#include<SFML/GRAPHICS/Sprite.hpp>
#include <map>
using namespace std;
using namespace sf;
class SpriteFactory {
	static SpriteFactory* INSTANCE;
	map<string, Sprite> tab_Sprite;
	Texture txtPacman, txtFantRouge, txtFantBleu, txtFantRose, txtGomme, txtStartMenu, txtGameOver, txtGameWin;
	Sprite sptPacman, sptFantRouge, sptFantBleu, sptFantRose, sptGomme, sptStartMenu, sptGameOver, sptGameWin;
	SpriteFactory();
	~SpriteFactory();

public:
	static SpriteFactory* getInstance();
	Sprite getSprite(string nom);
	void setTaille(int largeur, int hauteur);
};
