#pragma once
#include "GameElement.h"

class FantomeRose : public GameElement {
public:
	FantomeRose(Sommet<InfoSommet> *position, int etat = GameElement::NORMAL) :GameElement(position, etat) {}
	virtual ~FantomeRose() {}
	Sprite getSprite() const {
		return SpriteFactory::getInstance()->getSprite("FantRose");
	}

};
