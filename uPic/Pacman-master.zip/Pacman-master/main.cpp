#include <iostream>
#include <sstream>
#include <string>

#include "Partie.h"


using namespace std;
using namespace sf;

int main()
{
	Font font;
	bool ok = font.loadFromFile("mespolices\\ActionManBoldItalic.ttf");
	string titre("Pacman");
	int largeur = 1500, hauteur = 1500;

	//Vecteur2D  coinBG(0,hauteur), coinHD(largeur,0);
	Vecteur2D  coinBG(-0.5, -0.5), coinHD(6, 6);

	unsigned int fondCarte = 0xEFEFEFFF;	// sorte de gris clair ~= �tain pur


	FenetreGrapheSFML fenetreGraphe( titre, fondCarte, coinBG, coinHD, largeur, hauteur, font);
	


	Partie::getInstance()->lancerPartie(fenetreGraphe);


	return 0;
}
