#pragma once
#include "GameElement.h"
// � faire comme Pacman
class Gomme : public GameElement {
	int score;
public:
	Gomme(Sommet<InfoSommet> *position, int score, int etat=GameElement::NORMAL): GameElement(position, etat), score(score){}
	int getScore()const {
		return score;
	}
	void setScore(int s) {
		score = s;
	}
	~Gomme() {}
	Sprite getSprite() const {
		return SpriteFactory::getInstance()->getSprite("Gomme");
	}
};