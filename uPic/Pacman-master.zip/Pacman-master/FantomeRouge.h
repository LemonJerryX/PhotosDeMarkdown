#pragma once
#include "GameElement.h"

class FantomeRouge : public GameElement {
public:
	FantomeRouge(Sommet<InfoSommet> *position, int etat = GameElement::NORMAL) :GameElement(position, etat) {}
	virtual ~FantomeRouge() {}
	Sprite getSprite() const {
		return SpriteFactory::getInstance()->getSprite("FantRouge");
	}

};
