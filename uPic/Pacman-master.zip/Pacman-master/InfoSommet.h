#pragma once
#include "VSommet.h"
#include "InfoAStar.h"
#include "GameElement.h"
class GameElement;
/**

Information associ�e � un lieu (donc un sommet) d'une carte g�ographique pour laquelle on veut faire "tourner" A*

*/

class InfoSommet
{
public:
	VSommet vSommet;
	InfoAStar infoAStar;
	vector<GameElement *> contenu;
	InfoSommet(const VSommet & vSommet, const InfoAStar & infoAStar) : vSommet(vSommet), infoAStar(infoAStar) {}

	void addElement(GameElement* element) {
		contenu.push_back(element);
	}

	void deleteElement(GameElement* element) {
		vector<GameElement*>::iterator it = find(contenu.begin(), contenu.end(), element);
		if (it != contenu.end())
			contenu.erase(it);
	}

	operator string() const { ostringstream oss; oss << vSommet << endl; oss << infoAStar; return oss.str(); }

	friend ostream & operator <<(ostream & os, const InfoSommet & infoSommet) { return os << (string)infoSommet; }
};




