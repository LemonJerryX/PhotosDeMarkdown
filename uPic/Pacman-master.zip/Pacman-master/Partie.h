#pragma once
#include "Maze.h"
#include "Pacman.h"
#include "FantomeBleu.h"
#include "FantomeRose.h"
#include "FantomeRose.h"
#include "FenetreGrapheSFML.h"
#include "Gomme.h"
#include "AStarT.h"
#include <SFML/Window/Event.hpp>
#include <SFML/Window/Keyboard.hpp>
//pour g�n�rer un nb al�atoire
#include <cstdlib>
#include <time.h>
#include "OutilsCarte.h"
#include "Outils.h"
#include "AStarT.h"

class Partie {
	
	static Partie* INSTANCE;
	Maze m;
	int score = 0;
	int lifePoints = 2;
	int nbGommes = 0;
	bool endGame = false;
	bool winGame = false;
	Partie(){}
	~Partie() {}
	

	void initPosGameElement(GameElement& g) {
		g.setPosition(g.getInitPosition());
	}

	// Si le chemin existe on retourne le sommet suivant, sinon NULL
	Sommet<InfoSommet>* existCheminRectiligne(GameElement& a, GameElement& b);

	//retourner retourner le gomme s'il est dans le sommet, NULL sinon
	GameElement* existGomme(Sommet<InfoSommet>* noeud);

public:
	static Partie* getInstance();
	static void killInstance();
	void lancerPartie(FenetreGrapheSFML &window);
	bool deplacerPacman(GameElement& personnage, int direction);
	bool deplacerFantome(GameElement& personnage, GameElement& cible, int niveau);
	//Initialiser les gommes
	void InitGomme(Sommet<InfoSommet> *posPacman, int score);
};
Partie* Partie::INSTANCE = NULL;


Sommet<InfoSommet>* Partie::existCheminRectiligne(GameElement & personnage, GameElement & cible)
{
	int clePersonnage = personnage.getPosition()->clef;
	int cleCible = cible.getPosition()->clef;
	int direction = -1;
	//�a veut dire qu'il se trouve dans une m�me ligne
	if (clePersonnage / Maze::MAZE_LARGEUR == cleCible / Maze::MAZE_LARGEUR){
		(clePersonnage > cleCible) ? direction = Maze::G : direction =  Maze::D;
	}
	else if(clePersonnage % Maze::MAZE_LARGEUR == cleCible % Maze::MAZE_LARGEUR){
		(clePersonnage > cleCible) ? direction = Maze::H : direction = Maze::B;
	}
	
	//J'ai pas encore fait pour rectangle, reste � trouver une formule
	if (direction != -1)
		return m.graphe.getSommetParClef(personnage.getPosition()->clef + Maze::calculeDecalageClef(direction));
	
	return NULL;
}

GameElement* Partie::existGomme(Sommet<InfoSommet>* noeud)
{
	Gomme* g;
	for (int i = 0; i < noeud->v.contenu.size(); i++) {
		if (g = dynamic_cast<Gomme*>(noeud->v.contenu[i]))
			return noeud->v.contenu[i];
	}
	return NULL;
}



Partie* Partie::getInstance() {
	if (INSTANCE == NULL)
		INSTANCE = new Partie();
	return INSTANCE;
}

void Partie::killInstance()
{
	if (INSTANCE != NULL) {
		delete INSTANCE;
		INSTANCE = NULL;
	}
}



bool Partie::deplacerPacman(GameElement& personnage, int direction) {
	Sommet<InfoSommet>* s;
	GameElement *g;
	if ((s = m.graphe.getSommetParClef(personnage.getPosition()->clef + Maze::calculeDecalageClef(direction))) != NULL)
		if (m.graphe.getAreteParSommets(s, personnage.getPosition())) {
			m.graphe.getAreteParSommets(s, personnage.getPosition())->v.poids = 0x000000FF;
			if (g = existGomme(s)) {
				s->v.deleteElement(g);
				score += ((Gomme*)g)->getScore();
				cout << "Score = " << score << endl;
				cout << "Gommes = " << nbGommes << endl;
				cout << "Life points = " << lifePoints << endl;
				nbGommes--;
			}
			personnage.setPosition(s);
			
			return true;
		}	
	return false;
			
}



bool Partie::deplacerFantome(GameElement & personnage, GameElement & cible, int niveau)
{	
	Sommet<InfoSommet>* pos_suivant= personnage.getPosition();
	//utilise un design pattern ?
	//Niveau1
	if (niveau == 1) {
		srand((unsigned)time(NULL));
		//niveau 1, d�placement al�atoire
		int degre = personnage.getPosition()->degre;

		PElement<Sommet<InfoSommet>>* lvoisins = m.graphe.voisins(personnage.getPosition());
		for (int i = 1; i < rand() % degre + 1; i++)
			lvoisins = lvoisins->s;
		pos_suivant = lvoisins->v;
	}
	else if(niveau == 2){
		//Au vue
		if (!(pos_suivant = existCheminRectiligne(personnage, cible))) {
			//Au flair
			PElement<Sommet<InfoSommet>>* lvoisins = m.graphe.voisins(personnage.getPosition());
			Arete<InfoArete, InfoSommet>* aux;
			unsigned int poids_max = 0x00000000;
			for (; lvoisins; lvoisins = lvoisins->s)
			{
				aux = m.graphe.getAreteParSommets(personnage.getPosition(), lvoisins->v);
				if (aux->v.poids >= poids_max) {
					poids_max = aux->v.poids;
					pos_suivant = lvoisins->v;
				}
			}
		}
	}
	else {
		OutilsCarte::cible = cible.getPosition();
		if (AStarT<Graphe<InfoArete, InfoSommet>, Sommet<InfoSommet>>::aStar1Cible(m.graphe, personnage.getPosition(), cible.getPosition(), OutilsCarte::distance)) {
			PElement<Sommet<InfoSommet>>* c;
			chemin(cible.getPosition(), c);
			//Le premier element est le somemt de d�part, pour connaire le suivant, on prend le deuxi�me �l�ment
			if (PElement<Sommet<InfoSommet>>::taille(c) > 1)
				c = c->s;
			pos_suivant = c->v;
		}


	}
	

	
	for (int i = 0; i < pos_suivant->v.contenu.size(); i++) {
		if (pos_suivant->v.contenu[i] == &cible) {
			initPosGameElement(cible);
			lifePoints--;
		}	
	}

	personnage.setPosition(pos_suivant);
	return true;
	//return false;
}

void Partie::InitGomme(Sommet<InfoSommet>* posPacman, int score)
{
	for (int i = 0; i < m.sommets.size(); i++) {
		if (m.sommets[i] != posPacman) {
			new Gomme(m.sommets[i], score);
			nbGommes++;
		}
	}
}



void Partie::lancerPartie(FenetreGrapheSFML& window) {
	/*Initialiser les personnages*/
	Pacman pacman(m.sommets[11]);
	InitGomme(pacman.getPosition(),10);
	FantomeBleu fb(m.sommets[9]);
	//FantomeRose fr(m.sommets[16]);


	//le niveau, pour tester il reste � 1
	int NIVEAU = 1;

	//On d�finit une chronometre
	sf::Clock clock;

	//boolean qui d�termine si les fant�mes peuvent se d�placer
	bool pacmanADeplace = false;
	bool menu = true;

	while (window.fenetre.isOpen()) {

		sf::Event event;
		sf::Time elapsed = clock.getElapsedTime();
		
		while(menu) {
			if (window.fenetre.pollEvent(event)) {
				if (event.type == Event::Closed)
					window.fenetre.close();
				if (event.type == Event::KeyPressed) {
					menu = false;
					break;
				}
			}
			Sprite sptStartMenu = SpriteFactory::getInstance()->getSprite("StartMenu");
			sptStartMenu.setScale(Vector2f(1.5, 1.5));
			sptStartMenu.setPosition(Vector2f(40, 150));
			window.fenetre.clear();
			window.fenetre.draw(sptStartMenu);
			window.fenetre.display();
		}

		if(window.fenetre.pollEvent(event)) {
			if (event.type == Event::Closed)
				window.fenetre.close();
			if (event.type == Event::KeyPressed) {
				Event::KeyEvent touche = event.key;
				Keyboard::Key codeTouche = touche.code;
				if (elapsed.asSeconds() > 1.0f) {
					cout << "touche clavier tap�e : " << (char)codeTouche << (int)codeTouche << endl;
					switch (codeTouche)
					{
						case Keyboard::R:
							pacmanADeplace = deplacerPacman(pacman, Maze::GH);
							break;
						case Keyboard::T:
							pacmanADeplace = deplacerPacman(pacman, Maze::H);
							break;
						case Keyboard::Y:
							pacmanADeplace = deplacerPacman(pacman, Maze::DH);
							break;
						case Keyboard::H:
							pacmanADeplace = deplacerPacman(pacman, Maze::D);
							break;
						case Keyboard::N:
							pacmanADeplace = deplacerPacman(pacman, Maze::DB);
							break;
						case Keyboard::B:
							pacmanADeplace = deplacerPacman(pacman, Maze::B);
							break;
						case Keyboard::V:
							pacmanADeplace = deplacerPacman(pacman, Maze::GB);
							break;
						case Keyboard::F:
							pacmanADeplace = deplacerPacman(pacman, Maze::G);
							break;
						case Keyboard::G:
							pacmanADeplace = deplacerPacman(pacman, 0);
							break;
						default:
							break;
					}
					if (pacmanADeplace) {
						endGame = (lifePoints == 0 || nbGommes == 0);
						//On d�place les fant�mes et refroidir les aretes
						deplacerFantome(fb, pacman, NIVEAU);
						//deplacerFantome(fr, pacman, NIVEAU);
						m.refroidirAretes();
						clock.restart();
						pacmanADeplace = false;
					}
				}
			}
		}
		//Control du d�roulement
		if (nbGommes == 0 && NIVEAU < 3) {
			endGame = false;
			NIVEAU++;
			lifePoints = 2;
			/*Initialisation des personnages*/
			initPosGameElement(pacman);
			//initPosGameElement(fr);
			InitGomme(pacman.getPosition(), 10);
			//Faire une boucle sur tous les fantomes quand il y en aura plusieurs
			initPosGameElement(fb);
			//initPosGameElement(fr);
		}

		while (endGame) {
			window.fenetre.clear();
			Sprite sptGameOver;
			nbGommes == 0? sptGameOver = SpriteFactory::getInstance()->getSprite("GameWin"): sptGameOver = SpriteFactory::getInstance()->getSprite("GameOver");
			sptGameOver.setScale(Vector2f(5, 5));
			sptGameOver.setPosition(Vector2f(40, 150));
			window.fenetre.draw(sptGameOver);
			window.fenetre.display();

			if (window.fenetre.pollEvent(event)) {
				if (event.type == Event::Closed)
					window.fenetre.close();
				if (event.type == Event::KeyPressed) {
					endGame = false;
					menu = true;
					//break;
				}
			}
		}

		window.fenetre.clear();
		m.graphe.dessine(window);
		window.fenetre.display();
	}
}